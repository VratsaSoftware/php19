<footer class="navbar-default navbar-fixed-bottom">
    <div class="container-fluid">
        <span>Developed by Stanislav Ginev</span>
    </div>
</footer>

</body>
</html>