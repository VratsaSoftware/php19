<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task One</title>
</head>
<body>
    <form action="file.php" method="POST">
     <h3>Enter age:</h3>
     <input type="number" min=1 max=30 name='date'>
     <input type="submit">
    </form>
</body>
</html>