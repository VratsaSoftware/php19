<!DOCTYPE html>
<html>
<head>
	<title>Задача 1</title>
</head>
<body>
	<form method="post" action="suggested_clothing.php">
		Изберете дата <input type="number" name="date" min="1" max="30">
		<input type="submit" name="submit" value="Давай">		
	</form>
</body>
</html>