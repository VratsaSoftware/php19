<!DOCTYPE html>
<html>
<head>
	<title>Изпит Петър Иванов</title>
</head>
<body>
	<ul>
		<li>
			<a href="tasks/task_1.php">Задача 1</a>
		</li>
		<li>
			<a href="tasks/task_2.php">Задача 2</a>
		</li>
		<li>
			<a href="tasks/task_3.php">Задача 3</a>
		</li>

	</ul>
</body>
</html>