<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>входни данни</title>
</head>
<body>
	<form action="file.php" method="post">
		Въведете число от 1 до 30: 
		<input type="number" min=1 max=30 name="n">
		<input type="submit" name="submit" value="изпрати">		
	</form>	
</body>
</html>