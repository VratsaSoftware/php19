<!DOCTYPE html>
<html>
<head>
	<title>Task 1</title>
</head>
<body>
	<form action="output.php" method="post">
		<h2>Въведете дата:</h2>
		<input type="text" name="date">
		<p></p>
		<input type="submit" name="submit">
	</form>
</body>
</html>